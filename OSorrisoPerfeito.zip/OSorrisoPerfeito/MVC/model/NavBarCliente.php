<nav class="navbar navbar-dark bg-dark">
    <div class="container-md">
        <a class="navbar-brand" href="#">Painel do Cliente</a>
    </div>
</nav>