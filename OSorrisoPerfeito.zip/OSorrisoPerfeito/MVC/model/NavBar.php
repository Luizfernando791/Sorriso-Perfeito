<nav class="navbar navbar-dark bg-dark">
    <div class="container-md">
        <a class="navbar-brand" href="#">Painel do Administrador</a>
    </div>
</nav>